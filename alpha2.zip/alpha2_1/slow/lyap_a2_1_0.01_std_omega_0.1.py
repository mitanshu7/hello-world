## Importing a bunch                                                                 
import numpy as np
import os
import nolds
from time import time
from datetime import datetime

tic = time()

##Helper Functions
def importer(seed, alpha_in, alpha_out, nearest_neighbour):

    
    
    # Specify the name of the .npz file within the archive
    npz_file_name = f"data/evo/mu_{0.1}_std_{0.01}/seed_{seed}/in_{alpha_in}_out_{alpha_out}/k_{nearest_neighbour}/time_series_ep_0.1_in_{alpha_in}_out_{alpha_out}_k_{nearest_neighbour}.npz"

    # Specify the name of the array you want to load
    array_name = "arr_0" # Default name


    npz_data = np.load(npz_file_name)

                # Access and use the array
    my_array = npz_data[array_name]

    return my_array

def create_folder(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

##Number of oscillators
num_nodes=50

##The parameters of the model
meanW=0.1
sigma=0.01
al_in_list = np.arange(0.5,20.5,0.5)
al_out_list = [1.0]
k_list = np.arange(1,int(num_nodes/2)+1)
seed_list = np.arange(1,11)
nos_list = np.arange(num_nodes)


## Code to calculate Largest lyapunov exponent for the last 50% of time steps
for seed_count, seed_value in enumerate(seed_list):

    folder_name = f"data/lyap/mu_{meanW}_std_{sigma}/seed_{seed_value}"
    
    create_folder(folder_name)

    lyap_exp_matrix = np.zeros(( al_in_list.shape[0], k_list.shape[0], nos_list.shape[0]  ))

    for alpha1_count, alpha1_value in enumerate(al_in_list):

        for alpha2_count,alpha2_value in enumerate(al_out_list):
          
            for k_count, k_val in enumerate(k_list):

                timeseries = importer(seed_value, alpha1_value, alpha2_value, k_val)

                for node in range(50):

                    print(f"Processing seed = {seed_value}, alpha1 = {alpha1_value}, alpha2 = {alpha2_value}, k = {k_val}, node = {node} at time = {datetime.fromtimestamp(time()).strftime('%H:%M:%S')}")

                    half_time = int(len(timeseries[:,node])/2)

                    lyap_exp_matrix[alpha1_count, k_count, node] = nolds.lyap_r(timeseries[half_time:,node])


    path = os.path.join(folder_name,'lyap_exp')

    np.savez(path,lyap_exp_matrix)


toc = time()

print(f"The program took {toc-tic} seconds to run")