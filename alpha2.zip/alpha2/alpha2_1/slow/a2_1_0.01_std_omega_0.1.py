## Importing

import numpy as np
from numba import njit
import os
import networkx as nx
import time


#-------------------------------------------------------------------------------------------------------------------#

# Start the timer
start_time = time.time()

#-------------------------------------------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------------------------------------------#

## Initialising neccessary constants 

#useful constant
twopi = 2*np.pi

#No of Oscillators
number_of_oscillators = 50

#Epsilon
#epsilon0=0.33

#Alpha
#alpha0=2.1

meanW=0.1
sigma=0.01
#sigma_c=0.5625

#Intrinsic omegas
#omega0 = np.random.rand(number_of_oscillators)
np.random.seed(11)
omega = np.random.normal(meanW, sigma, number_of_oscillators) 
#print("The initial values of omega's = ", omega)

#Theta vector

#print("The initial values of theta's: ",theta0)

# Coupling vector
np.random.seed(33)
k0 = nx.adjacency_matrix(nx.erdos_renyi_graph(n=number_of_oscillators, p=0.2, seed=14, directed=False)).toarray()
#print("The initial values of coupling matrix is: ",k0)


##Initial Condition to feed in the oscillator 
#init_con = np.append(theta0,k0)
#print("The initial condition of modified kuramoto function is: ",init_con)

#start of Time period
t0 = 0

#Time step
h=0.05

#end of time period
tf = 500

# Total number of steps taken
steps = int((tf-t0)/h)

# X-axis for plots
time_axis = np.arange(t0,tf,h)

#-------------------------------------------------------------------------------------------------------------------#

## More parameters, sigh

#alpha1 = 3.0 ## Inside the radius

#alpha2 = 2.0 ## Outside the radius

#-------------------------------------------------------------------------------------------------------------------#

num_nodes=number_of_oscillators
    
#-------------------------------------------------------------------------------------------------------------------#

## Declaring functions

def create_folder(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

@njit
def nssk(theta, matrix, alphanssk, epsilonnssk):

    ## Creating skeletons to manipulate
    theta_in = theta
    theta_out = np.zeros_like(theta)
    matrix_in = matrix 
    matrix_out = np.zeros_like(matrix)

    ## Action on theta
    for i in range(len(matrix_in)):
        for j in range(len(matrix_in[0])):
            theta_out[i] = theta_out[i] + ( 1/number_of_oscillators )*( matrix_in[i][j] )*( np.sin(theta_in[j] - theta_in[i]) ) 

    theta_out = theta_out + omega

    ## Action on matrix
    for i in range(len(matrix_in)):
        for j in range(len(matrix_in[0])):
            matrix_out[i][j] = (epsilonnssk)*( alphanssk[i][j]*(np.cos(theta_in[j] - theta_in[i])) - matrix_in[i][j]) 

    return theta_out%twopi,matrix_out

@njit
def rk4_nssk(initial_theta, initial_matrix, alphark4, epsilonrk4):

    
    ## Creating skeletons for solutions
    final_theta = np.zeros((steps,len(initial_theta)))
    final_matrix = np.zeros(( steps, len(initial_matrix), len(initial_matrix)))

    ## Loading the initial condition
    final_theta[0,:] = initial_theta
    final_matrix[0,:,:] = initial_matrix
    
    ## Working runge kutta magic
    for i in range(steps-1):
        tk1, mk1 = nssk(theta=final_theta[i,:], matrix=final_matrix[i,:,:], alphanssk=alphark4, epsilonnssk=epsilonrk4)
        tk2, mk2 = nssk(theta=final_theta[i,:]+(tk1*h/2), matrix=final_matrix[i,:,:]+(mk1*h/2), alphanssk=alphark4, epsilonnssk=epsilonrk4)
        tk3, mk3 = nssk(theta=final_theta[i,:]+(tk2*h/2), matrix=final_matrix[i,:,:]+(mk2*h/2), alphanssk=alphark4, epsilonnssk=epsilonrk4)
        tk4, mk4 = nssk(theta=final_theta[i,:]+(tk3*h), matrix=final_matrix[i,:,:]+(mk3*h), alphanssk=alphark4, epsilonnssk=epsilonrk4)
    
        final_theta[i+1,:] = final_theta[i,:] + (h/6)*(tk1 + 2*tk2 + 2*tk3 + tk4)
        final_matrix[i+1,:,:] = final_matrix[i,:,:] + (h/6)*(mk1 + 2*mk2 + 2*mk3 + mk4)

    return final_theta,final_matrix

@njit
def coherence_calculator1(solution, start_oi=0, stop_oi=number_of_oscillators):
    
    #Using the above calculated solution via rk4 method:

    r = np.zeros((steps,1))

    cosines = np.cos(1*solution)
    sines = np.sin(1*solution)


    mean_cos = np.zeros((steps,1))

    for j in range(steps):
        mean_cos[j] = mean_cos[j] + np.mean(cosines[j,start_oi:stop_oi])

    mean_sin = np.zeros((steps,1))

    for k in range(steps):
        mean_sin[k] = mean_sin[k] + np.mean(sines[k,start_oi:stop_oi])

    coherence = np.sqrt( mean_cos**2 + mean_sin**2 )

    return coherence

@njit
def coherence_calculator2(solution, start_oi=0, stop_oi=number_of_oscillators):
    
    #Using the above calculated solution via rk4 method:

    r = np.zeros((steps,1))

    cosines = np.cos(2*solution)
    sines = np.sin(2*solution)


    mean_cos = np.zeros((steps,1))

    for j in range(steps):
        mean_cos[j] = mean_cos[j] + np.mean(cosines[j,start_oi:stop_oi])

    mean_sin = np.zeros((steps,1))

    for k in range(steps):
        mean_sin[k] = mean_sin[k] + np.mean(sines[k,start_oi:stop_oi])

    coherence = np.sqrt( mean_cos**2 + mean_sin**2 )

    return coherence

@njit
def ring_plasticity_matrix_creator(adj_mat_in,alpha_high, alpha_low):

    ##Creating a alpha matrix with binary values which take a value of alpha1 if the distance between those nodes is less than or equal to some radius
    ##otherwise it takes the value of alpha2
    alpha_matrix = np.zeros_like(adj_mat_in)

    ##iterating over the distance matrix to check the radius
    for i in range(len(adj_mat_in)):
        for j in range(len(adj_mat_in[0])):
            if adj_mat_in[i][j] ==  1:
                alpha_matrix[i][j] = alpha_high
            else:
                alpha_matrix[i][j] = alpha_low

    return alpha_matrix

#@njit
def ring_graph5(n, k):
    ## From https://stackoverflow.com/questions/64603777/two-ways-to-create-a-ring-graph
    nxk = np.arange(0, n).repeat(k)
    src = nxk.reshape(n, k)
    dst = np.mod(np.tile(np.arange(0, k), n) + (nxk + 1), n).reshape((n, k))
    flat_pairs = np.dstack((src, dst)).flatten().tolist()
    return zip(flat_pairs[::2], flat_pairs[1::2])
#-------------------------------------------------------------------------------------------------------------------#

al_in_list = np.arange(0.0,20.5,0.5)
al_out_list = [1.0]
k_list = np.arange(int(num_nodes/2)+1)

nill_matrix = np.zeros_like(k0)

seed_list = np.arange(1,11)

R1_matrix = np.zeros(( len(seed_list), len(al_in_list), len(k_list)))
R2_matrix = np.zeros(( len(seed_list), len(al_in_list), len(k_list)))


## Driver Code
ep=0.1



#optim_K = np.array([], dtype=float)
for seed_count, seed_value in enumerate(seed_list):

    np.random.seed(seed_value)
    theta0 = twopi*np.random.rand(number_of_oscillators)

    for alpha1_count, alpha1_value in enumerate(al_in_list):
        for alpha2_count,alpha2_value in enumerate(al_out_list):

          
            for k_count, k_val in enumerate(k_list):
            


                folder_name =f"data/evo/mu_{meanW}_std_{sigma}/seed_{seed_value}/in_{alpha1_value}_out_{alpha2_value}/k_{k_val}"
                create_folder(folder_name)

                ## Creating the adjacency matrix
                G = nx.from_edgelist(ring_graph5(number_of_oscillators, k_val))

                adjacency_matrix = nx.to_numpy_array(G)

                    ## 
                alpha_mat = ring_plasticity_matrix_creator(adj_mat_in=adjacency_matrix, alpha_high=alpha1_value, alpha_low=alpha2_value)

                    ##FOR STRICT RING, we replace the Kij with alpha mat
                nssk_solved_theta, nssk_solved_matrix = rk4_nssk(initial_theta=theta0, initial_matrix=nill_matrix, alphark4=alpha_mat, epsilonrk4=ep)

                    ## Saving matrices
                path=os.path.join(folder_name, "time_series_ep_%s_in_%s_out_%s_k_%s.npz"%(ep,alpha1_value,alpha2_value,k_val))
                ##Saving only last 20%
                last_x_percent = int(-0.2*(nssk_solved_theta.shape[0]))
                save_solved_theta = nssk_solved_theta[last_x_percent:,:]
                np.savez_compressed(path,save_solved_theta)  

                    ##    
                path=os.path.join(folder_name, "coupling_mat_evolution_ep_%s_in_%s_out_%s_k_%s.npz"%(ep,alpha1_value,alpha2_value,k_val))
                ##Saving only last 20%
                last_x_percent = int(-0.2*(nssk_solved_matrix.shape[0]))
                save_solved_matrix = nssk_solved_matrix[last_x_percent:,:,:]                
                np.savez_compressed(path,save_solved_matrix)
                        
                    ##    
                nssk_r = coherence_calculator1(nssk_solved_theta)
                transient_time = int(-0.2*steps)
                mean_value = np.mean(nssk_r[transient_time:])
                R1_matrix[ seed_count, alpha1_count, k_count ] = mean_value


                nssk_r = coherence_calculator2(nssk_solved_theta)
                transient_time = int(-0.2*steps)
                mean_value = np.mean(nssk_r[transient_time:])
                R2_matrix[ seed_count, alpha1_count, k_count ] = mean_value

np.savez_compressed(f"R1_matrix_mu_{meanW}_std_{sigma}_a2_{al_out_list[0]}", R1_matrix)
np.savez_compressed(f"R2_matrix_mu_{meanW}_std_{sigma}_a2_{al_out_list[0]}", R2_matrix)

#-------------------------------------------------------------------------------------------------------------------#

# End the timer
end_time = time.time()

# Calculate the elapsed time
elapsed_time = end_time - start_time

# Print the elapsed time
print(f"\n Elapsed time: {elapsed_time} seconds \n")


