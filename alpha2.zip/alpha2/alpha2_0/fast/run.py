import subprocess
import glob

# Get Python file names matching a specific pattern (e.g., all .py files in the current directory)
python_files = glob.glob('*.py')
python_files.remove('run.py') # Remove the current file to not enter an infinite loop
python_files.sort()

# Execute each Python file using subprocess.run() and save stdout and stderr to files
for file_name in python_files:
    stdout_file = f"{file_name[:-3]}_stdout.txt"  # Create a filename for stdout
    stderr_file = f"{file_name[:-3]}_stderr.txt"  # Create a filename for stderr

    with open(stdout_file, 'w') as stdout, open(stderr_file, 'w') as stderr:
        command = f"nohup python3 {file_name} > {stdout_file} 2> {stderr_file} &"
        subprocess.run(command, shell=True, stdout=stdout, stderr=stderr)
